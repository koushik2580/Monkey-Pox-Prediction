# MONKEYPOX-DISEASE-PREDICTION-
monkey pox disease prediction using csv and image dataset
